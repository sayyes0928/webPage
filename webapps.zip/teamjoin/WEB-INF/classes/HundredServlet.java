import javax.servlet.http.*;
import javax.servlet.*;
import java.io.*;

public class HundredServlet extends HttpServlet
{
	 public void doGet(HttpServletRequest request, HttpServletResponse response)
		 throws IOException, ServletException
	{ 
		 response.setContentType("text/html; charset=utf-8");
	
	   PrintWriter out = response.getWriter();
	   out.println("<html><head><title>���� ���α׷� - �Է� ȭ��</title><head>");
	   out.println("<body> ss");
	   out.println("<img src = './img/dog1.jpg'/>");

	   out.println("</body></html>");
	  }
}
